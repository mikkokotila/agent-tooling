"""Compatibility entrypoint. The shared native hook is the sole stop authority."""
import json
import sys

def handle(event):
    return None

def run():
    # Older live sessions may still invoke this command; never duplicate decisions.
    return None

def install():
    return {"installed": False, "superseded_by": "caller-pr-gates shared native hooks", "reason": "A second stop controller is disabled"}

if __name__ == '__main__':
    run()
